<?php
include 'connect.php';

$id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM theaters WHERE theater_id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $theater_name = $_POST['theater_name'];
    $location = $_POST['location'];

    if (!empty($_FILES['file']['name'])) {
        $fileName = $_FILES['file']['name'];
        $fileTmp  = $_FILES['file']['tmp_name'];
        $fileType = $_FILES['file']['type'];
        $fileSize = $_FILES['file']['size'];

        $folder = "images/theaters/" . basename($fileName);
        $allowed = ['image/jpg', 'image/png', 'image/jpeg'];

        if (in_array(strtolower($fileType), $allowed) && $fileSize <= 1000000) {
            if (move_uploaded_file($fileTmp, $folder)) {
                $update = "UPDATE theaters SET theater_name='$theater_name', location='$location', theater_img='$folder' WHERE theater_id=$id";
            }
        }
    } else {
        $update = "UPDATE theaters SET theater_name='$theater_name', location='$location' WHERE theater_id=$id";
    }

    if ($conn->query($update)) {
        echo "<script>alert('Theater updated'); window.location='read_theaters.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Theater</title>
</head>
<body>
<h2>Edit Theater</h2>
<form method="post" enctype="multipart/form-data">
    Name: <input type="text" name="theater_name" value="<?= $row['theater_name'] ?>" required><br><br>
    Location: <input type="text" name="location" value="<?= $row['location'] ?>" required><br><br>
    Current Image: <br>
    <img src="<?= $row['theater_img'] ?>" width="150"><br><br>
    Upload New Image: <input type="file" name="file"><br><br>
    <button type="submit">Update</button>
</form>
</body>
</html>
