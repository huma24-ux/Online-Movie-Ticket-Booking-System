<?php
include 'connect.php';

$sql = "SELECT * FROM theaters";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Theaters</title>
</head>
<body>
<h2>Theaters</h2>
<a href="create_theater.php">+ Add New Theater</a>
<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Image</th>
        <th>Name</th>
        <th>Location</th>
        <th>Actions</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()) { ?>
    <tr>
        <td><?= $row['theater_id'] ?></td>
        <td><img src="<?= $row['theater_img'] ?>" width="100" height="80"></td>
        <td><?= $row['theater_name'] ?></td>
        <td><?= $row['location'] ?></td>
        <td>
            <a href="edit_theater.php?id=<?= $row['theater_id'] ?>">Edit</a> | 
            <a href="delete_theater.php?id=<?= $row['theater_id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
        </td>
    </tr>
    <?php } ?>
</table>
</body>
</html>
