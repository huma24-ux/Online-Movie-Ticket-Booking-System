<?php
include 'connect.php';
$result = $conn->query("SELECT * FROM movies");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Movies List</title>
    <style>
        body {
            margin: 30px;
            font-family: Arial, sans-serif;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        img {
            margin: 5px 0;
        }
        a {
            margin-right: 8px;
        }
    </style>
</head>
<body>
<h2>Movies</h2>
<a href="create_movie.php">Add New Movie</a><br><br>
<table border="1" cellpadding="10">
<tr>
    <th>ID</th><th>Title</th><th>Description</th><th>Trailer</th><th>Date</th>
    <th>Duration</th><th>Rating</th><th>Image</th><th>Actions</th>
</tr>
<?php while ($row = $result->fetch_assoc()) { ?>
<tr>
    <td><?= $row['movie_id'] ?></td>
    <td><?= htmlspecialchars($row['title']) ?></td>
    <td><?= htmlspecialchars($row['description']) ?></td>
    <td><a href="<?= $row['trailer_url'] ?>" target="_blank">Watch</a></td>
    <td><?= $row['release_date'] ?></td>
    <td><?= $row['duration'] ?> min</td>
    <td><?= $row['rating'] ?></td>
    <td><img src="<?= $row['movie_img'] ?>" width="100"></td>
    <td>
        <a href="edit_movie.php?id=<?= $row['movie_id'] ?>">Edit</a> | 
        <a href="delete_movie.php?id=<?= $row['movie_id'] ?>" onclick="return confirm('Delete this movie?')">Delete</a>
    </td>
</tr>
<?php } ?>
</table>
</body>
</html>
