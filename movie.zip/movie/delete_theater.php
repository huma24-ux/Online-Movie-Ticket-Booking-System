<?php
include 'connect.php';

$id = $_GET['id'];
$sql = "DELETE FROM theaters WHERE theater_id=$id";

if ($conn->query($sql)) {
    echo "<script>alert('Theater deleted'); window.location='read_theaters.php';</script>";
} else {
    echo "Error: " . $conn->error;
}
?>
