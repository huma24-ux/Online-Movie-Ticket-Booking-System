<?php
include 'connect.php';

if (isset($_POST['ins'])) {
    $theater_name = $_POST['theater_name'];
    $location = $_POST['location'];

    $fileName = $_FILES['file']['name'];
    $fileTmp  = $_FILES['file']['tmp_name'];
    $fileType = $_FILES['file']['type'];
    $fileSize = $_FILES['file']['size'];

    $uploadDir = "images/theaters/";
    $folder = $uploadDir . basename($fileName);

    // Ensure directory exists
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);  // create folder if not exists
    }

    $allowed = ['image/jpg', 'image/png', 'image/jpeg'];

    if (in_array(strtolower($fileType), $allowed)) {
        if ($fileSize <= 1000000) {
            if (move_uploaded_file($fileTmp, $folder)) {
                $sql = "INSERT INTO theaters (theater_img, theater_name, location) 
                        VALUES ('$folder', '$theater_name', '$location')";
                if ($conn->query($sql)) {
                    echo "<script>alert('Theater added successfully'); window.location='read_theaters.php';</script>";
                } else {
                    echo "Error: " . $conn->error;
                }
            } else {
                echo "<script>alert('Failed to upload image');</script>";
            }
        } else {
            echo "<script>alert('File size must be less than 1MB');</script>";
        }
    } else {
        echo "<script>alert('Invalid file type');</script>";
    }
}
?>
