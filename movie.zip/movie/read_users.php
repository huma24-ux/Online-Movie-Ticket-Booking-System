<?php
include 'connect.php';

$result = $conn->query("SELECT * FROM users");
?>

<style>
table {
    border-collapse: collapse;
    width: 80%;
    margin: 30px auto;
    box-shadow: 0 2px 8px #ccc;
}
th, td {
    border: 1px solid #888;
    padding: 12px 18px;
    text-align: left;
}
th {
    background: #f2f2f2;
}
tr:nth-child(even) {
    background: #fafafa;
}
tr:hover {
    background: #e6f7ff;
}
</style>

<table>
<tr>
    <th>ID</th><th>Name</th><th>Email</th><th>Age</th><th>Role</th><th>Actions</th>
</tr>
<?php while($row = $result->fetch_assoc()) { ?>
<tr>
    <td><?= $row['user_id'] ?></td>
    <td><?= $row['full_name'] ?></td>
    <td><?= $row['email'] ?></td>
    <td><?= $row['age'] ?></td>
    <td><?= $row['role'] ?></td>
    <td>
        <a href="edit_users.php?id=<?= $row['user_id'] ?>">Edit</a> | 
        <a href="delete_users.php?id=<?= $row['user_id'] ?>" onclick="return confirm('Delete this user?')">Delete</a>
    </td>
</tr>
<?php } ?>
</table>
